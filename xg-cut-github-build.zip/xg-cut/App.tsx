import { StatusBar } from 'expo-status-bar';
import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Dimensions,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
  NativeModules,
  Platform,
} from 'react-native';

const { width } = Dimensions.get('window');
const C = {
  bg: '#050507', panel: '#101016', panel2: '#171721', ink: '#F7F4FA', muted: '#8D8A9A',
  pink: '#FF1F8F', pinkSoft: '#FF6DBA', purple: '#8B5CF6', blue: '#2ED8FF', line: '#262431', green: '#9EFFB8',
};

type Screen = 'home' | 'editor';
type Effect = { name: string; icon: string; color: string };
const effects: Effect[] = [
  { name: 'Glow', icon: '✦', color: C.pink }, { name: 'Chromatic', icon: '◈', color: C.blue },
  { name: 'Motion', icon: '↝', color: C.purple }, { name: 'Blur', icon: '◌', color: '#FFB86B' },
  { name: 'VHS', icon: '▥', color: '#B7FF76' }, { name: 'Echo', icon: '◒', color: '#FF7CF2' },
];
const projects = [
  { title: 'neon city / 01', meta: '00:24  ·  1080p', palette: ['#150B29', '#FF1F8F', '#2ED8FF'] },
  { title: 'afterglow', meta: '00:11  ·  Draft', palette: ['#101B31', '#8B5CF6', '#FFB86B'] },
  { title: 'night drive', meta: '00:38  ·  4K', palette: ['#081B1D', '#9EFFB8', '#2ED8FF'] },
];

function IconButton({ label, glyph, onPress, active = false, accent = C.pink }: { label: string; glyph: string; onPress?: () => void; active?: boolean; accent?: string }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.iconButton, active && { borderColor: accent, backgroundColor: `${accent}18` }, pressed && styles.pressed]}>
    <Text style={[styles.iconGlyph, { color: active ? accent : C.ink }]}>{glyph}</Text>
    <Text style={[styles.iconLabel, active && { color: accent }]}>{label}</Text>
  </Pressable>;
}

function ProjectCard({ project, onPress }: { project: (typeof projects)[number]; onPress: () => void }) {
  return <Pressable onPress={onPress} style={({ pressed }) => [styles.projectCard, pressed && styles.pressed]}>
    <View style={[styles.thumbnail, { backgroundColor: project.palette[0] }]}>
      <View style={[styles.thumbGlow, { backgroundColor: project.palette[1], top: 14, left: 16 }]} />
      <View style={[styles.thumbGlow, { backgroundColor: project.palette[2], bottom: 10, right: 12, width: 48, height: 48 }]} />
      <View style={styles.playDot}><Text style={styles.playGlyph}>▶</Text></View>
      <View style={styles.duration}><Text style={styles.durationText}>{project.meta.split('  ·  ')[0]}</Text></View>
    </View>
    <View style={styles.cardCopy}><Text style={styles.projectTitle}>{project.title}</Text><Text style={styles.projectMeta}>{project.meta}</Text></View>
  </Pressable>;
}

function Home({ openProject }: { openProject: () => void }) {
  const [imported, setImported] = useState(false);
  const handleImport = () => { setImported(true); openProject(); };
  return <ScrollView contentContainerStyle={styles.homeContent} showsVerticalScrollIndicator={false}>
    <View style={styles.heroRow}><View><Text style={styles.kicker}>LOCAL EDITOR / 01</Text><Text style={styles.wordmark}>XG <Text style={styles.wordmarkAccent}>Cut</Text></Text></View><View style={styles.statusPill}><View style={styles.liveDot} /><Text style={styles.statusText}>OFFLINE</Text></View></View>
    <Text style={styles.heroSubtitle}>shape the frame. <Text style={{ color: C.pinkSoft }}>your way.</Text></Text>
    <View style={styles.importSection}>
      <View style={[styles.orbit, styles.orbitOne]} /><View style={[styles.orbit, styles.orbitTwo]} />
      <Pressable onPress={handleImport} style={({ pressed }) => [styles.importButton, pressed && styles.importPressed]}><Text style={styles.plus}>+</Text><Text style={styles.importLabel}>{imported ? 'MEDIA ADDED' : 'IMPORT MEDIA'}</Text><Text style={styles.importHint}>photos · video · audio</Text></Pressable>
    </View>
    <View style={styles.sectionHeader}><Text style={styles.sectionTitle}>MY PROJECTS</Text><Text style={styles.sectionCount}>03 / 12</Text></View>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.projectRail}>{projects.map((project) => <ProjectCard key={project.title} project={project} onPress={openProject} />)}</ScrollView>
    <View style={styles.tipCard}><View style={styles.tipIcon}><Text style={{ color: C.blue, fontSize: 19 }}>⌁</Text></View><View style={{ flex: 1 }}><Text style={styles.tipTitle}>everything stays on-device</Text><Text style={styles.tipBody}>No ads. No accounts. Your edits never leave your phone.</Text></View><Text style={styles.tipArrow}>↗</Text></View>
  </ScrollView>;
}

function EffectSheet({ visible, selected, onClose, onSelect }: { visible: boolean; selected: string; onClose: () => void; onSelect: (name: string) => void }) {
  return <Modal visible={visible} transparent animationType="slide" onRequestClose={onClose}><View style={styles.modalBackdrop}><View style={styles.effectSheet}><View style={styles.sheetHandle} /><View style={styles.sheetHeader}><View><Text style={styles.sheetKicker}>NEW / EFFECT MATRIX</Text><Text style={styles.sheetTitle}>shape the energy</Text></View><Pressable onPress={onClose} style={styles.closeButton}><Text style={styles.closeText}>×</Text></Pressable></View><View style={styles.effectGrid}>{effects.map((effect) => <Pressable key={effect.name} onPress={() => onSelect(effect.name)} style={[styles.effectTile, selected === effect.name && { borderColor: effect.color, backgroundColor: `${effect.color}14` }]}><Text style={[styles.effectIcon, { color: effect.color }]}>{effect.icon}</Text><Text style={styles.effectName}>{effect.name}</Text>{selected === effect.name && <View style={[styles.selectedMark, { backgroundColor: effect.color }]} />}</Pressable>)}</View><Text style={styles.adjustLabel}>INTENSITY <Text style={{ color: C.muted }}> / {selected.toUpperCase()}</Text></Text><View style={styles.sliderTrack}><View style={[styles.sliderFill, { width: '68%' }]} /><View style={styles.sliderKnob} /></View><View style={styles.sliderMeta}><Text style={styles.sliderValue}>68%</Text><Text style={styles.sliderHint}>drag to adjust</Text></View><Pressable onPress={onClose} style={styles.applyButton}><Text style={styles.applyText}>APPLY EFFECT</Text><Text style={styles.applyArrow}>→</Text></Pressable></View></View></Modal>;
}

function Editor({ goHome }: { goHome: () => void }) {
  const [sheetOpen, setSheetOpen] = useState(false);
  const [selectedEffect, setSelectedEffect] = useState('Glow');
  const [exporting, setExporting] = useState(false);
  const [saved, setSaved] = useState(false);
  const [tab, setTab] = useState('EDIT');
  const exportClip = () => { setExporting(true); setTimeout(() => { setExporting(false); setSaved(true); Alert.alert('Export complete', 'Your 1080p clip is ready in the device gallery.'); }, 1100); };
  return <View style={styles.editorScreen}>
    <View style={styles.editorTop}><Pressable onPress={goHome}><Text style={styles.backArrow}>←</Text></Pressable><View><Text style={styles.editorKicker}>PROJECT / NEON CITY 01</Text><Text style={styles.editorTitle}>neon city / 01</Text></View><Pressable onPress={exportClip} style={styles.exportMini}><Text style={styles.exportMiniText}>{saved ? 'SAVED' : 'EXPORT'}</Text></Pressable></View>
    <View style={styles.previewFrame}><View style={styles.previewSky} /><View style={styles.previewBeam} /><View style={[styles.previewBeam, { backgroundColor: C.blue, transform: [{ rotate: '-32deg' }], left: 110, top: 95 }]} /><View style={styles.previewCenter}><Text style={styles.previewWord}>XG</Text><Text style={styles.previewSub}>CUT / 01</Text></View><View style={styles.previewTopLine}><Text style={styles.previewBadge}>REC 00:24</Text><Text style={styles.previewBadge}>1080p · 60</Text></View><View style={styles.previewPlay}><Text style={styles.previewPlayGlyph}>▶</Text></View></View>
    <View style={styles.timelineHeader}><Text style={styles.sectionTitle}>TIMELINE</Text><Text style={styles.timelineTime}>00:12.40 / 00:24.00</Text></View><View style={styles.timeline}><View style={styles.trackLabel}><Text style={styles.trackIcon}>V</Text></View><View style={styles.trackBody}><View style={[styles.clip, { backgroundColor: '#31104B', width: '72%' }]}><Text style={styles.clipText}>NEON CITY</Text></View><View style={[styles.clip, { backgroundColor: '#102B3B', width: '42%', marginTop: 7 }]}><Text style={styles.clipText}>AUDIO / ORIGINAL</Text></View><View style={styles.playhead} /></View></View>
    <View style={styles.dock}><IconButton label="RECORD" glyph="●" accent={C.pink} onPress={() => Alert.alert('Record', 'Camera and microphone are ready locally.')} /><IconButton label="NEW" glyph="＋" active accent={C.blue} onPress={() => setSheetOpen(true)} /><IconButton label="MODIFY" glyph="⌘" onPress={() => setSheetOpen(true)} /></View>
    <View style={styles.editorTabs}>{['EDIT', 'COLOR', 'AUDIO'].map((item) => <Pressable key={item} onPress={() => setTab(item)} style={[styles.editorTab, tab === item && styles.editorTabActive]}><Text style={[styles.editorTabText, tab === item && { color: C.pink }]}>{item}</Text></Pressable>)}</View>
    <Text style={styles.localNote}>● LOCAL PROCESSING ENABLED  ·  FFmpeg / TFLite ready</Text>
    <EffectSheet visible={sheetOpen} selected={selectedEffect} onClose={() => setSheetOpen(false)} onSelect={(name) => { setSelectedEffect(name); }} />
    {exporting && <View style={styles.exportOverlay}><View style={styles.exportCard}><Text style={styles.exportKicker}>RENDERING LOCALLY</Text><Text style={styles.exportTitle}>exporting your cut</Text><View style={styles.exportTrack}><View style={styles.exportFill} /></View><Text style={styles.exportPercent}>68%  ·  1080p / 60fps</Text></View></View>}
  </View>;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [bootMessage] = useState('Native modules guarded · offline mode');
  useEffect(() => {
    if (Platform.OS !== 'android') return;
    try {
      NativeModules.XgNative?.getCapabilities?.().catch(() => undefined);
      NativeModules.XgNative?.initializeTensorFlowLite?.().catch(() => undefined);
    } catch (_) {
      // A missing native module is non-fatal; the editor remains usable in offline UI mode.
    }
  }, []);
  const footer = useMemo(() => screen === 'home' ? 'XG CUT / ZERO CLOUD DEPENDENCY' : bootMessage.toUpperCase(), [screen, bootMessage]);
  return <SafeAreaView style={styles.safe}><StatusBar style="light" /><View style={styles.app}>{screen === 'home' ? <Home openProject={() => setScreen('editor')} /> : <Editor goHome={() => setScreen('home')} />}<Text style={styles.footer}>{footer}</Text></View></SafeAreaView>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg }, app: { flex: 1, backgroundColor: C.bg }, homeContent: { paddingHorizontal: 20, paddingTop: 24, paddingBottom: 26 },
  heroRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' }, kicker: { color: C.muted, fontSize: 10, letterSpacing: 2.4, fontWeight: '700' }, wordmark: { color: C.ink, fontSize: 40, fontWeight: '900', letterSpacing: -2, marginTop: 4 }, wordmarkAccent: { color: C.pink }, statusPill: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: C.line, borderRadius: 20, paddingHorizontal: 11, paddingVertical: 7, marginTop: 5 }, liveDot: { width: 6, height: 6, borderRadius: 4, backgroundColor: C.green, marginRight: 6 }, statusText: { color: C.muted, fontSize: 9, letterSpacing: 1.3, fontWeight: '700' }, heroSubtitle: { color: C.ink, fontSize: 17, marginTop: 14, letterSpacing: .2 },
  importSection: { height: 246, alignItems: 'center', justifyContent: 'center', position: 'relative' }, orbit: { position: 'absolute', borderWidth: 1, borderRadius: 200, borderColor: `${C.pink}35` }, orbitOne: { width: 210, height: 210, transform: [{ rotate: '18deg' }] }, orbitTwo: { width: 160, height: 160, borderColor: `${C.blue}30`, transform: [{ rotate: '-26deg' }] }, importButton: { width: 132, height: 132, borderRadius: 70, backgroundColor: C.pink, alignItems: 'center', justifyContent: 'center', shadowColor: C.pink, shadowOpacity: .55, shadowRadius: 24, shadowOffset: { width: 0, height: 6 }, elevation: 14 }, importPressed: { transform: [{ scale: .96 }], opacity: .9 }, plus: { color: '#FFF', fontSize: 52, fontWeight: '200', lineHeight: 54 }, importLabel: { color: '#FFF', fontSize: 9, letterSpacing: 1.7, fontWeight: '800', marginTop: -2 }, importHint: { color: '#FFD4EA', fontSize: 9, marginTop: 6 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }, sectionTitle: { color: C.ink, fontSize: 11, letterSpacing: 2, fontWeight: '800' }, sectionCount: { color: C.muted, fontSize: 11, letterSpacing: 1 }, projectRail: { gap: 12, paddingBottom: 16 }, projectCard: { width: Math.min(width * .66, 240), borderRadius: 16, backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, overflow: 'hidden' }, thumbnail: { height: 132, overflow: 'hidden', position: 'relative' }, thumbGlow: { position: 'absolute', width: 80, height: 80, borderRadius: 60, opacity: .85, shadowColor: '#FFF', shadowOpacity: .5, shadowRadius: 28 }, playDot: { position: 'absolute', alignSelf: 'center', top: 47, width: 38, height: 38, borderRadius: 22, backgroundColor: '#090910B8', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#FFFFFF55' }, playGlyph: { color: '#FFF', fontSize: 12, marginLeft: 2 }, duration: { position: 'absolute', right: 9, bottom: 8, backgroundColor: '#050507B8', paddingHorizontal: 6, paddingVertical: 3, borderRadius: 5 }, durationText: { color: '#FFF', fontSize: 9, fontWeight: '700' }, cardCopy: { padding: 12 }, projectTitle: { color: C.ink, fontSize: 13, fontWeight: '700' }, projectMeta: { color: C.muted, fontSize: 10, marginTop: 5 },
  tipCard: { flexDirection: 'row', alignItems: 'center', gap: 11, backgroundColor: C.panel, borderWidth: 1, borderColor: C.line, padding: 13, borderRadius: 14, marginTop: 8 }, tipIcon: { width: 32, height: 32, borderRadius: 10, backgroundColor: `${C.blue}14`, alignItems: 'center', justifyContent: 'center' }, tipTitle: { color: C.ink, fontSize: 11, fontWeight: '700' }, tipBody: { color: C.muted, fontSize: 10, marginTop: 4 }, tipArrow: { color: C.muted, fontSize: 20 },
  editorScreen: { flex: 1, paddingHorizontal: 16, paddingTop: 16 }, editorTop: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 18 }, backArrow: { color: C.ink, fontSize: 27, paddingRight: 3 }, editorKicker: { color: C.muted, fontSize: 9, letterSpacing: 1.3 }, editorTitle: { color: C.ink, fontSize: 16, fontWeight: '800', marginTop: 2 }, exportMini: { marginLeft: 'auto', borderWidth: 1, borderColor: C.pink, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 7 }, exportMiniText: { color: C.pink, fontSize: 9, letterSpacing: 1.2, fontWeight: '800' }, previewFrame: { height: 255, backgroundColor: '#101323', borderRadius: 16, overflow: 'hidden', position: 'relative', borderWidth: 1, borderColor: C.line }, previewSky: { position: 'absolute', width: 220, height: 220, borderRadius: 200, backgroundColor: '#50105A', opacity: .65, top: 28, left: 32 }, previewBeam: { position: 'absolute', width: 300, height: 38, backgroundColor: C.pink, opacity: .55, transform: [{ rotate: '22deg' }], top: 78, left: -60, borderRadius: 30 }, previewCenter: { position: 'absolute', alignSelf: 'center', top: 86, alignItems: 'center' }, previewWord: { color: '#FFF', fontSize: 64, letterSpacing: -5, fontWeight: '900', textShadowColor: C.pink, textShadowRadius: 24 }, previewSub: { color: '#FFFFFFBB', letterSpacing: 4, fontSize: 9 }, previewTopLine: { position: 'absolute', top: 14, left: 14, right: 14, flexDirection: 'row', justifyContent: 'space-between' }, previewBadge: { color: '#FFFFFFAA', fontSize: 9, letterSpacing: 1 }, previewPlay: { position: 'absolute', bottom: 14, alignSelf: 'center', width: 42, height: 42, borderRadius: 24, backgroundColor: '#050507AA', alignItems: 'center', justifyContent: 'center' }, previewPlayGlyph: { color: '#FFF', fontSize: 13, marginLeft: 2 },
  timelineHeader: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 19, marginBottom: 10 }, timelineTime: { color: C.muted, fontSize: 10, letterSpacing: .4 }, timeline: { flexDirection: 'row', height: 83, backgroundColor: C.panel, borderRadius: 11, borderWidth: 1, borderColor: C.line, overflow: 'hidden' }, trackLabel: { width: 32, backgroundColor: '#181721', alignItems: 'center', justifyContent: 'center' }, trackIcon: { color: C.pink, fontSize: 13, fontWeight: '900' }, trackBody: { flex: 1, padding: 9, position: 'relative' }, clip: { height: 25, borderRadius: 5, justifyContent: 'center', paddingHorizontal: 8, borderLeftWidth: 3, borderLeftColor: C.pink }, clipText: { color: '#FFFFFFAA', fontSize: 8, letterSpacing: 1 }, playhead: { position: 'absolute', top: 0, bottom: 0, left: '46%', width: 1, backgroundColor: C.blue }, dock: { flexDirection: 'row', justifyContent: 'space-around', paddingVertical: 19, borderBottomWidth: 1, borderBottomColor: C.line }, iconButton: { width: 94, height: 58, borderWidth: 1, borderColor: C.line, backgroundColor: C.panel, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, iconGlyph: { fontSize: 20, fontWeight: '700', marginBottom: 4 }, iconLabel: { color: C.muted, fontSize: 8, letterSpacing: 1, fontWeight: '800' }, pressed: { opacity: .72, transform: [{ scale: .98 }] }, editorTabs: { flexDirection: 'row', gap: 24, paddingTop: 16, paddingBottom: 12 }, editorTab: { paddingBottom: 7, borderBottomWidth: 2, borderBottomColor: 'transparent' }, editorTabActive: { borderBottomColor: C.pink }, editorTabText: { color: C.muted, fontSize: 10, letterSpacing: 1.7, fontWeight: '800' }, localNote: { color: `${C.green}AA`, fontSize: 8, letterSpacing: .7, marginTop: 'auto', marginBottom: 10, textAlign: 'center' }, footer: { color: '#514E5C', fontSize: 8, letterSpacing: 1.6, textAlign: 'center', paddingBottom: 8 },
  modalBackdrop: { flex: 1, justifyContent: 'flex-end', backgroundColor: '#000000AA' }, effectSheet: { backgroundColor: C.panel, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, paddingBottom: 28, borderTopWidth: 1, borderColor: C.line }, sheetHandle: { width: 38, height: 4, backgroundColor: '#FFFFFF33', borderRadius: 3, alignSelf: 'center', marginBottom: 19 }, sheetHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }, sheetKicker: { color: C.muted, fontSize: 9, letterSpacing: 1.8, fontWeight: '800' }, sheetTitle: { color: C.ink, fontSize: 23, fontWeight: '800', marginTop: 5 }, closeButton: { width: 31, height: 31, borderRadius: 16, backgroundColor: C.panel2, alignItems: 'center', justifyContent: 'center' }, closeText: { color: C.muted, fontSize: 22, lineHeight: 23 }, effectGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 }, effectTile: { width: '31.7%', aspectRatio: 1.12, borderWidth: 1, borderColor: C.line, borderRadius: 12, backgroundColor: C.panel2, padding: 10, justifyContent: 'space-between', position: 'relative' }, effectIcon: { fontSize: 28 }, effectName: { color: C.ink, fontSize: 10, fontWeight: '700' }, selectedMark: { position: 'absolute', width: 7, height: 7, borderRadius: 5, top: 10, right: 10 }, adjustLabel: { color: C.ink, fontSize: 10, letterSpacing: 1.5, fontWeight: '800', marginTop: 21, marginBottom: 12 }, sliderTrack: { height: 4, backgroundColor: '#2A2833', borderRadius: 4, position: 'relative' }, sliderFill: { height: 4, backgroundColor: C.pink, borderRadius: 4 }, sliderKnob: { position: 'absolute', width: 16, height: 16, borderRadius: 9, backgroundColor: '#FFF', borderWidth: 3, borderColor: C.pink, top: -6, left: '66%' }, sliderMeta: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9 }, sliderValue: { color: C.pink, fontSize: 11, fontWeight: '800' }, sliderHint: { color: C.muted, fontSize: 10 }, applyButton: { marginTop: 18, backgroundColor: C.pink, borderRadius: 12, height: 48, alignItems: 'center', justifyContent: 'center', flexDirection: 'row' }, applyText: { color: '#FFF', fontSize: 10, fontWeight: '900', letterSpacing: 1.4 }, applyArrow: { color: '#FFF', fontSize: 19, marginLeft: 14 }, exportOverlay: { ...StyleSheet.absoluteFill, backgroundColor: '#050507EE', alignItems: 'center', justifyContent: 'center' }, exportCard: { width: '84%', backgroundColor: C.panel, borderWidth: 1, borderColor: C.pink, borderRadius: 16, padding: 22 }, exportKicker: { color: C.pink, fontSize: 9, letterSpacing: 1.7, fontWeight: '800' }, exportTitle: { color: C.ink, fontSize: 21, fontWeight: '800', marginTop: 7 }, exportTrack: { height: 6, backgroundColor: '#2A2833', borderRadius: 6, marginTop: 24, overflow: 'hidden' }, exportFill: { width: '68%', height: 6, backgroundColor: C.pink }, exportPercent: { color: C.muted, fontSize: 10, marginTop: 9 },
});
