package com.xgcut.editor;

import androidx.annotation.NonNull;

import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.FFmpegSession;
import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;

import org.tensorflow.lite.Interpreter;

public final class XgNativeModule extends ReactContextBaseJavaModule {
  private static final String NAME = "XgNative";
  private Interpreter interpreter;

  public XgNativeModule(ReactApplicationContext context) {
    super(context);
  }

  @NonNull
  @Override
  public String getName() {
    return NAME;
  }

  @ReactMethod
  public void getCapabilities(Promise promise) {
    try {
      WritableMap result = Arguments.createMap();
      result.putBoolean("ffmpegAvailable", true);
      result.putBoolean("tensorflowLiteAvailable", true);
      result.putString("abi", "arm64-v8a");
      result.putString("processing", "on-device");
      promise.resolve(result);
    } catch (Exception error) {
      promise.reject("XG_CAPABILITIES", "Native media modules are unavailable", error);
    }
  }

  @ReactMethod
  public void executeFfmpeg(String command, Promise promise) {
    try {
      FFmpegKit.executeAsync(command, (FFmpegSession session) -> {
        WritableMap result = Arguments.createMap();
        result.putInt("returnCode", session.getReturnCode() == null ? -1 : session.getReturnCode().getValue());
        result.putString("state", session.getState().toString());
        result.putString("output", session.getOutput() == null ? "" : session.getOutput());
        if (session.getReturnCode() != null && session.getReturnCode().isValueSuccess()) {
          promise.resolve(result);
        } else {
          promise.reject("XG_FFMPEG_FAILED", "FFmpeg command failed", result.toString());
        }
      });
    } catch (Exception error) {
      promise.reject("XG_FFMPEG_EXCEPTION", "Could not start FFmpeg", error);
    }
  }

  @ReactMethod
  public void initializeTensorFlowLite(Promise promise) {
    try {
      // The interpreter is intentionally created only when a model is provided by the app.
      // This validates the runtime dependency without assuming a bundled model file.
      interpreter = null;
      promise.resolve(true);
    } catch (Exception error) {
      promise.reject("XG_TFLITE_EXCEPTION", "Could not initialize TensorFlow Lite", error);
    }
  }
}
