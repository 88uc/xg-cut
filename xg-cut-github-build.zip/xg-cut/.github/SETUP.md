# إعداد GitHub Actions لبناء APK

## الأسرار المطلوبة في GitHub Repository

أضف الأسرار التالية من **Settings → Secrets and variables → Actions**:

- `ANDROID_KEYSTORE_BASE64`: محتوى `android/app/xgcut-release.keystore` بعد ترميزه:

  ```bash
  base64 -w 0 android/app/xgcut-release.keystore
  ```

- `XG_RELEASE_STORE_PASSWORD`: `xgcut-local-release` للمفتاح الذي تم إنشاؤه داخل Sandbox، أو كلمة مرور مفتاح جديد.
- `XG_RELEASE_KEY_PASSWORD`: كلمة مرور المفتاح نفسه.
- `XG_RELEASE_KEY_ALIAS`: `xgcut`.

لا تضع ملف keystore أو كلمات المرور داخل Git. ملف workflow يعيد إنشاء keystore داخل runner مؤقتاً، ثم يرفع APK فقط كـArtifact.

## تشغيل البناء

1. ادفع المشروع إلى مستودع GitHub خاص.
2. أضف الأسرار السابقة.
3. افتح تبويب **Actions**.
4. اختر **Build XG Cut Android APK**.
5. اضغط **Run workflow**.
6. بعد النجاح، نزّل Artifact باسم `xg-cut-release-arm64`.

التحقق داخل workflow يرفض أي APK يحتوي مكتبات `armeabi-v7a` أو `x86` أو `x86_64`، ويتطلب وجود `arm64-v8a`.
