# XG Cut Android Build Status

## تم إنجازه

- Android SDK command-line tools مثبتة في `/home/ubuntu/android-sdk`.
- Android Platform 36 وBuild Tools 36 وNDK وCMake مثبتة.
- تم إنشاء مشروع Android Native عبر `expo prebuild`.
- تم تفعيل `arm64-v8a` فقط في `android/app/build.gradle` و`android/gradle.properties`.
- تم تفعيل `android:hardwareAccelerated="true"`.
- تمت إضافة قواعد R8/ProGuard لحماية جسر XG Cut وFFmpeg وTensorFlow Lite.
- تمت إضافة مكتبات Maven الفعلية:
  - `dev.ffmpegkit-maintained:ffmpeg-kit-full-gpl:6.0.3`
  - `org.tensorflow:tensorflow-lite:2.17.0`
- تمت إضافة `XgNativeModule` فعلياً مع أساليب `executeFfmpeg`, `getCapabilities`, و`initializeTensorFlowLite` وربطه بـReact Native.
- تم إنشاء مفتاح Release محلي باسم `android/app/xgcut-release.keystore` وربطه بتكوين Release.
- تمت إضافة `.github/workflows/build.yml` لبناء وتوقيع APK على GitHub Actions باستخدام runner x86_64، مع فحص صارم لمكتبات `arm64-v8a`.

## نتيجة محاولة البناء في Sandbox

الـSandbox الحالية تعمل بمعمارية **aarch64**. Android SDK الرسمي المتاح عبر `sdkmanager` يثبت أدوات Linux x86-64 فقط، ومن ضمنها `aapt2`. فشل Gradle برسالة `Exec format error` عند تشغيل AAPT2.

تمت إضافة `android.aapt2FromMaven=true` وإعادة المحاولة، لكن Gradle ظل يفشل عند تشغيل AAPT2 لأن artifact المتاح أيضاً لا يقدم binary قابلاً للتشغيل على aarch64 في هذه البيئة.

لذلك لا يوجد APK صالح للتنزيل من Sandbox الحالية. لا ينبغي إنشاء رابط وهمي.

## المسار الموصى به

استخدم سير عمل GitHub Actions المرفق:

1. أنشئ مستودعاً خاصاً على GitHub.
2. ارفع الكود.
3. أضف الأسرار الموضحة في `.github/SETUP.md`.
4. شغّل workflow يدوياً من تبويب Actions.
5. نزّل Artifact `xg-cut-release-arm64` بعد النجاح.

تم تصميم workflow ليبني APK موقّعاً ويمنع إدراج أي ABI غير `arm64-v8a`.
