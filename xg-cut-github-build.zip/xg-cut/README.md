# XG Cut

واجهة محرر فيديو جوال محلية مبنية بـ Expo / React Native، مستوحاة من محررات الفيديو الداكنة ذات الطابع النيون.

## ما تم تنفيذه

- لوحة Home بعلامة XG Cut، حالة Offline، وزر Import Media مركزي.
- بطاقات My Projects قابلة للنقر.
- مساحة تحرير بتجربة Preview، Timeline، Record، New، Modify.
- نافذة Effect Matrix تفاعلية مع Glow وChromatic وMotion وBlur وVHS وEcho.
- مؤشر ضبط شدة التأثير، واختيار تأثير فعال.
- تدفق Export محلي تجريبي مع progress overlay ورسالة حفظ إلى المعرض.
- هوية ألوان داكنة: أسود عميق مع Neon Pink وCyber Purple وNeon Blue.
- لا توجد إعلانات أو تتبع أو طلبات شبكة داخل منطق الواجهة.
- إعداد Expo بنمط Android داكن، اسم الحزمة `com.xgcut.editor`، وصلاحيات الكاميرا/الميكروفون/الوسائط.

## التشغيل

```bash
npm install
npm run web
```

للتشغيل عبر Expo على جهاز Android:

```bash
npx expo start
```

## الفحص

```bash
npx tsc --noEmit
npx expo export --platform web
```

## ملاحظة Native

هذه النسخة هي واجهة Expo محلية قابلة للمعاينة. دمج FFmpeg/TensorFlow Lite الحقيقي، بناء Native بامتداد `arm64-v8a`، قواعد R8/ProGuard، وتوقيع APK Release يتطلب إضافة مجلد Android وتشغيل Android SDK/Gradle أو خدمة بناء Android منفصلة. لم يتم الادعاء بإخراج APK موقّع من بيئة Sandbox الحالية.
